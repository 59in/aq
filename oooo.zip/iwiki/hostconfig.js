const hostconfig = require('./config.json');

module.exports = hostconfig;
